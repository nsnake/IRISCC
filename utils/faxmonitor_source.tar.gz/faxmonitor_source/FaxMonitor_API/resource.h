//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FaxMonitor.rc
//
#define VS_VERSION_INFO                 1
#define IDCANCEL                        2
#define IDD_DLG_FAXMONITOR              101
#define IDD_DLG_SEND                    129
#define IDC_EDT_URL                     1001
#define IDC_EDT_USER                    1002
#define IDC_EDT_PASSWORD                1003
#define IDC_EDT_ACCOUNT                 1004
#define IDC_EDT_NUMBER                  1005
#define IDC_BTN_SAVE                    1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
