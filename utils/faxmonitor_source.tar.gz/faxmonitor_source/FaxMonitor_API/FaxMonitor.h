/************************************************************************/
/*                                                                      */
/************************************************************************/

#ifndef FaxMonitor_h_xx
#include <windows.h>
#include <shlwapi.h> 
#include <string>
#include "resource.h"
#include <phprpc_client.hpp>
#pragma   comment(lib,"shlwapi") 
#pragma   comment(lib,   "ws2_32.lib")
#include <fstream>

class CFaxMonitorDlg
{
public:
	
	static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
    static int  OnBnClickedOk(HWND m_hwnd);
  	static void OnBnClickedBtnSave(HWND m_hwnd);

};

class CSendDlg
{
public:

	static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
	static int  OnBnClickedOk(HWND m_hwnd);
	

};

#endif
